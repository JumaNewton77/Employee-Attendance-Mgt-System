<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM employee WHERE email = '$email'";
    $run_Sql = mysqli_query($conn, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: Index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $fetch_info['fullname'] ?> | Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="dashbordhome.css"> -->
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');

* {
    margin: 0;
    padding: 0;
    /* box-sizing: border-box; */
}
        body{
            background-image: gold;
            background-size: cover;
        }

        body, h1, ul, li, a {
            margin: 0;
            padding: 0;
            text-decoration: none;
        }
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color:gold;
            color: white;
            padding: 20px;
            position: sticky;
            top: 0;  
            z-index: 1000;
         }
        nav {
            width: 90%;
            margin: 0 auto;
        }
        .logo{
            display: flex;
            padding: 5px 40px;
            font-size: 35px;
        }
        .logo a{
            text-decoration: none;
            color: rgb(28, 215, 34);
            text-size-adjust: 30px;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(rgb(248, 7, 7), purple);
           -webkit-text-fill-color: transparent;
           -webkit-background-clip: text;
        }
        #navli {
            list-style: none;  
            display: flex;
            justify-content: flex-end; 
        }
        #navli li {
            margin-left: 20px; 
        }
        #navli a {
            color: white; 
            transition: color 0.3s ease-in-out;
        }
        .homeblack:hover, .homered:hover {
            color: #ddd; 
        }
        .homered {
            color: #ff4500; 
        }
        #navli a:hover{
            background-color: goldenrod;
            justify-content: space-between;
            padding: 10px 2px;
        }body{
            background-image: gold;
            background-size: cover;
        }

        body, h1, ul, li, a {
            margin: 0;
            padding: 0;
            text-decoration: none;
        }
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color:gold;
            color: white;
            padding: 20px;
            position: sticky;
            top: 0;  
            z-index: 1000;
         }
        nav {
            width: 90%;
            margin: 0 auto;
        }
        .logo{
            display: flex;
            padding: 5px 40px;
            font-size: 35px;
        }
        .logo a{
            text-decoration: none;
            color: rgb(28, 215, 34);
            text-size-adjust: 30px;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(rgb(248, 7, 7), purple);
           -webkit-text-fill-color: transparent;
           -webkit-background-clip: text;
        }
        #navli {
            list-style: none;  
            display: flex;
            justify-content: flex-end; 
        }
        #navli li {
            margin-left: 20px; 
        }
        #navli a {
            color: white; 
            transition: color 0.3s ease-in-out;
        }
        .homeblack:hover, .homered:hover {
            color: #ddd; 
        }
        .homered {
            color: #ff4500; 
        }
        #navli a:hover{
            background-color: goldenrod;
            justify-content: space-between;
            padding: 10px 2px;
        }
    h1{
        position: absolute;
        top: 50%;
        left: 50%;
        width: 100%;
        text-align: center;
        transform: translate(-50%, -50%);
        font-size: 50px;
        font-weight: 600;
    }



    .button-container {
            position: fixed; /* or 'absolute' depending on use case */
            top: 6px;
            right: 5px;
            padding: 10px;
        }
        .btn {
        display: inline-block;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        outline: none;
        color: white;
        background-color: blue;
        border: none;
        border-radius: 5px;
        box-shadow: 0 2px green;
    }
    .btn:hover { background-color: violet }
    .btn a {
        color: white; 
        text-decoration: none;  
        display: block;  
    }



.main {
    flex: 1;
    padding: 20px;
    background-color: #f8f9fa;  
    /* min-height: 60vh;  */
}
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo"><a href="Home.html">EAMS</a></div>
            <ul id="navli">
                <li><a class="homeblack" href="home.html">Home</a></li>
                <li><a class="homeblack" href="services.html">Services</a></li>
                <li><a class="homered" href="contact.html">Contact Us</a></li>
                <li><a class="homeblack" href="login.html">Notification</a></li>
            </ul>
            <div class="button-container" style="float: right;">  
                <a href="logout-user.php" class="btn btn-light">Logout</a>  
            </div>
        </nav>
    </header>
    
    <main>
        <section class="welcome-message">
            <h1>Welcome <?php echo $fetch_info['fullname'] ?></h1>

            
        </section>
        
        <!-- Your main content goes here -->


    </main>

    

</body>
</html>