<?php
//require_once ($_SERVER['DOCUMENT_ROOT'] . '../Connect.php');
require_once "Connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $department_name = $_POST['dptname'];
    $head_of_department = $_POST['dpthod'];
    $department_ext_num = $_POST['dptextnum'];
    $department_email =$_POST['dptemail'];
    $department_address = $_POST['dptaddress'];
    $date_created = $_POST['dptdate']; 
    $department_location = $_POST['dptlocaton']; 

    $email_check = "SELECT * FROM department WHERE dpthod = '$head_of_department'";
    $sql = mysqli_query($conn, $email_check);
    if(mysqli_num_rows($sql) > 0){
        $errors['dpthod'] = "Head of department already exist!";
    }

    $stmt = $conn->prepare("INSERT INTO department (dptname, dpthod, dptextnum, dptemail, dptaddress, dptdate, dptlocaton) 
    VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        echo "Error preparing statement: " . $conn->error;
        exit;
    }

    $stmt->bind_param("ssissss", $department_name, $head_of_department, $department_ext_num, $department_email, $department_address, $date_created, $department_location);

    if ($stmt->execute()) {
        header('location: admin/admindash.php');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}

$conn->close();



?>
